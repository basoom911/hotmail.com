﻿namespace HuaweiUnlocker
{
    partial class Window
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

                                        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Window));
            this.pather = new System.Windows.Forms.TextBox();
            this.DETECTED = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LoaderBox = new System.Windows.Forms.ComboBox();
            this.AutoXml = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.nButton2 = new HuaweiUnlocker.UI.NButton();
            this.PatXm = new System.Windows.Forms.TextBox();
            this.Selecty2 = new HuaweiUnlocker.UI.NButton();
            this.Selecty3 = new HuaweiUnlocker.UI.NButton();
            this.RAW = new System.Windows.Forms.CheckBox();
            this.PTOFIRM = new System.Windows.Forms.Label();
            this.Xm = new System.Windows.Forms.TextBox();
            this.AutoLdr = new System.Windows.Forms.CheckBox();
            this.Tab = new System.Windows.Forms.TabControl();
            this.MA = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.DBB = new System.Windows.Forms.CheckBox();
            this.SelLanguage = new HuaweiUnlocker.UI.NButton();
            this.LBOX = new System.Windows.Forms.ComboBox();
            this.GLOADER = new System.Windows.Forms.GroupBox();
            this.SelectLOADER = new HuaweiUnlocker.UI.NButton();
            this.QCOM1 = new System.Windows.Forms.TabPage();
            this.TUTR2 = new System.Windows.Forms.Label();
            this.GPfir = new System.Windows.Forms.GroupBox();
            this.EraseMeBtn = new HuaweiUnlocker.UI.NButton();
            this.Flash = new HuaweiUnlocker.UI.NButton();
            this.DUMPALL = new HuaweiUnlocker.UI.NButton();
            this.Board = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.FrBTN = new HuaweiUnlocker.UI.NButton();
            this.RDinf = new HuaweiUnlocker.UI.NButton();
            this.ReBbtn = new HuaweiUnlocker.UI.NButton();
            this.UpgradMDbtn = new HuaweiUnlocker.UI.NButton();
            this.ACTBOX = new System.Windows.Forms.GroupBox();
            this.UnlockFrp = new HuaweiUnlocker.UI.NButton();
            this.EraseDA = new HuaweiUnlocker.UI.NButton();
            this.BoardU = new HuaweiUnlocker.UI.NButton();
            this.SLDEV = new System.Windows.Forms.GroupBox();
            this.DEVICER = new System.Windows.Forms.ComboBox();
            this.DevInfoQCBox = new System.Windows.Forms.GroupBox();
            this.MacLBL = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.AndrVerLBL = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.HWkey = new System.Windows.Forms.Label();
            this.CPUbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.VERbox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.CHIPbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BIDbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SNbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.IMEIbox = new System.Windows.Forms.TextBox();
            this.QCOM2 = new System.Windows.Forms.TabPage();
            this.RdGPT = new HuaweiUnlocker.UI.NButton();
            this.WHAT = new System.Windows.Forms.GroupBox();
            this.ReadPA = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.WritePA = new System.Windows.Forms.Button();
            this.ErasePA = new System.Windows.Forms.Button();
            this.PARTLIST = new System.Windows.Forms.DataGridView();
            this.P = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.O = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.L = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Diag = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.CLEARDD = new System.Windows.Forms.Button();
            this.FlashF = new System.Windows.Forms.Button();
            this.CMD = new System.Windows.Forms.TextBox();
            this.NC = new System.Windows.Forms.TabPage();
            this.CpuHISIBox = new System.Windows.Forms.GroupBox();
            this.HISIbootloaders = new System.Windows.Forms.ComboBox();
            this.DSGSDG = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.UNLOCKHISI = new HuaweiUnlocker.UI.NButton();
            this.HISI_board_FB = new HuaweiUnlocker.UI.NButton();
            this.EnDisFBLOCK = new System.Windows.Forms.CheckBox();
            this.FBLstHISI = new HuaweiUnlocker.UI.NButton();
            this.RdHISIinfo = new HuaweiUnlocker.UI.NButton();
            this.isVCOM = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ASERhisi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AVERhi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.BLkeyHI = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.BUIDhi = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.BSNhi = new System.Windows.Forms.TextBox();
            this.MTK1 = new System.Windows.Forms.TabPage();
            this.LOGGER = new System.Windows.Forms.TextBox();
            this.BURG = new System.Windows.Forms.Panel();
            this.DiagTag = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.HISItag = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.GPTtag = new System.Windows.Forms.Label();
            this.UnlockTag = new System.Windows.Forms.Label();
            this.BackupRestoreTag = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.HomeTag = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.BURGBTN = new System.Windows.Forms.Button();
            this.PGG = new HuaweiUnlocker.UI.NProgressBar();
            this.panel1.SuspendLayout();
            this.Tab.SuspendLayout();
            this.MA.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.GLOADER.SuspendLayout();
            this.QCOM1.SuspendLayout();
            this.GPfir.SuspendLayout();
            this.Board.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.ACTBOX.SuspendLayout();
            this.SLDEV.SuspendLayout();
            this.DevInfoQCBox.SuspendLayout();
            this.QCOM2.SuspendLayout();
            this.WHAT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PARTLIST)).BeginInit();
            this.Diag.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.NC.SuspendLayout();
            this.CpuHISIBox.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.BURG.SuspendLayout();
            this.SuspendLayout();
            // 
            // pather
            // 
            this.pather.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.pather.ForeColor = System.Drawing.SystemColors.WindowText;
            this.pather.Location = new System.Drawing.Point(6, 29);
            this.pather.Margin = new System.Windows.Forms.Padding(2);
            this.pather.Name = "pather";
            this.pather.Size = new System.Drawing.Size(270, 22);
            this.pather.TabIndex = 22;
            // 
            // DETECTED
            // 
            this.DETECTED.AutoSize = true;
            this.DETECTED.Cursor = System.Windows.Forms.Cursors.Default;
            this.DETECTED.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DETECTED.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.DETECTED.ForeColor = System.Drawing.Color.MintCream;
            this.DETECTED.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DETECTED.Location = new System.Drawing.Point(2, 60);
            this.DETECTED.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DETECTED.Name = "DETECTED";
            this.DETECTED.Size = new System.Drawing.Size(191, 19);
            this.DETECTED.TabIndex = 14;
            this.DETECTED.Text = "Rawprograms0 / Patch0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.MintCream;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(1, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 19);
            this.label1.TabIndex = 15;
            this.label1.Text = "MSM LOADER.MBN";
            // 
            // LoaderBox
            // 
            this.LoaderBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.LoaderBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LoaderBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LoaderBox.FormattingEnabled = true;
            this.LoaderBox.Location = new System.Drawing.Point(5, 44);
            this.LoaderBox.Margin = new System.Windows.Forms.Padding(2);
            this.LoaderBox.Name = "LoaderBox";
            this.LoaderBox.Size = new System.Drawing.Size(429, 24);
            this.LoaderBox.Sorted = true;
            this.LoaderBox.TabIndex = 20;
            // 
            // AutoXml
            // 
            this.AutoXml.AutoSize = true;
            this.AutoXml.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.AutoXml.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.AutoXml.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AutoXml.Location = new System.Drawing.Point(218, 61);
            this.AutoXml.Margin = new System.Windows.Forms.Padding(2);
            this.AutoXml.Name = "AutoXml";
            this.AutoXml.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.AutoXml.Size = new System.Drawing.Size(58, 20);
            this.AutoXml.TabIndex = 26;
            this.AutoXml.Text = "Auto";
            this.AutoXml.UseVisualStyleBackColor = true;
            this.AutoXml.CheckedChanged += new System.EventHandler(this.AutoXml_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.nButton2);
            this.panel1.Controls.Add(this.PatXm);
            this.panel1.Controls.Add(this.Selecty2);
            this.panel1.Controls.Add(this.Selecty3);
            this.panel1.Controls.Add(this.RAW);
            this.panel1.Controls.Add(this.PTOFIRM);
            this.panel1.Controls.Add(this.AutoXml);
            this.panel1.Controls.Add(this.pather);
            this.panel1.Controls.Add(this.Xm);
            this.panel1.Controls.Add(this.DETECTED);
            this.panel1.Location = new System.Drawing.Point(5, 5);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(358, 147);
            this.panel1.TabIndex = 25;
            // 
            // nButton2
            // 
            this.nButton2.AutoSize = true;
            this.nButton2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.nButton2.BackColorAdditional = System.Drawing.Color.Gray;
            this.nButton2.BackColorGradientEnabled = false;
            this.nButton2.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.nButton2.BorderColor = System.Drawing.Color.Tomato;
            this.nButton2.BorderColorEnabled = false;
            this.nButton2.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.nButton2.BorderColorOnHoverEnabled = false;
            this.nButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.nButton2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nButton2.ForeColor = System.Drawing.Color.White;
            this.nButton2.Location = new System.Drawing.Point(280, 112);
            this.nButton2.Margin = new System.Windows.Forms.Padding(2);
            this.nButton2.Name = "nButton2";
            this.nButton2.RippleColor = System.Drawing.Color.Black;
            this.nButton2.RoundingEnable = false;
            this.nButton2.Size = new System.Drawing.Size(65, 25);
            this.nButton2.TabIndex = 31;
            this.nButton2.Text = "Select";
            this.nButton2.TextHover = null;
            this.nButton2.UseDownPressEffectOnClick = false;
            this.nButton2.UseRippleEffect = true;
            this.nButton2.UseVisualStyleBackColor = false;
            this.nButton2.UseZoomEffectOnHover = false;
            this.nButton2.Click += new System.EventHandler(this.nButton2_Click);
            // 
            // PatXm
            // 
            this.PatXm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.PatXm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PatXm.Location = new System.Drawing.Point(6, 114);
            this.PatXm.Margin = new System.Windows.Forms.Padding(2);
            this.PatXm.Name = "PatXm";
            this.PatXm.Size = new System.Drawing.Size(270, 22);
            this.PatXm.TabIndex = 30;
            // 
            // Selecty2
            // 
            this.Selecty2.AutoSize = true;
            this.Selecty2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.Selecty2.BackColorAdditional = System.Drawing.Color.Gray;
            this.Selecty2.BackColorGradientEnabled = false;
            this.Selecty2.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.Selecty2.BorderColor = System.Drawing.Color.Tomato;
            this.Selecty2.BorderColorEnabled = false;
            this.Selecty2.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.Selecty2.BorderColorOnHoverEnabled = false;
            this.Selecty2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Selecty2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Selecty2.ForeColor = System.Drawing.Color.White;
            this.Selecty2.Location = new System.Drawing.Point(280, 83);
            this.Selecty2.Margin = new System.Windows.Forms.Padding(2);
            this.Selecty2.Name = "Selecty2";
            this.Selecty2.RippleColor = System.Drawing.Color.Black;
            this.Selecty2.RoundingEnable = false;
            this.Selecty2.Size = new System.Drawing.Size(65, 25);
            this.Selecty2.TabIndex = 29;
            this.Selecty2.Text = "Select";
            this.Selecty2.TextHover = null;
            this.Selecty2.UseDownPressEffectOnClick = false;
            this.Selecty2.UseRippleEffect = true;
            this.Selecty2.UseVisualStyleBackColor = false;
            this.Selecty2.UseZoomEffectOnHover = false;
            this.Selecty2.Click += new System.EventHandler(this.XML_PATH);
            // 
            // Selecty3
            // 
            this.Selecty3.AutoSize = true;
            this.Selecty3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.Selecty3.BackColorAdditional = System.Drawing.Color.Gray;
            this.Selecty3.BackColorGradientEnabled = false;
            this.Selecty3.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.Selecty3.BorderColor = System.Drawing.Color.Tomato;
            this.Selecty3.BorderColorEnabled = false;
            this.Selecty3.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.Selecty3.BorderColorOnHoverEnabled = false;
            this.Selecty3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Selecty3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Selecty3.ForeColor = System.Drawing.Color.White;
            this.Selecty3.Location = new System.Drawing.Point(280, 26);
            this.Selecty3.Margin = new System.Windows.Forms.Padding(2);
            this.Selecty3.Name = "Selecty3";
            this.Selecty3.RippleColor = System.Drawing.Color.Black;
            this.Selecty3.RoundingEnable = false;
            this.Selecty3.Size = new System.Drawing.Size(65, 25);
            this.Selecty3.TabIndex = 28;
            this.Selecty3.Text = "Select";
            this.Selecty3.TextHover = null;
            this.Selecty3.UseDownPressEffectOnClick = false;
            this.Selecty3.UseRippleEffect = true;
            this.Selecty3.UseVisualStyleBackColor = false;
            this.Selecty3.UseZoomEffectOnHover = false;
            this.Selecty3.Click += new System.EventHandler(this.PATHTOFIRMWARE_Clck);
            // 
            // RAW
            // 
            this.RAW.AutoSize = true;
            this.RAW.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.RAW.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.RAW.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.RAW.Location = new System.Drawing.Point(175, 2);
            this.RAW.Margin = new System.Windows.Forms.Padding(2);
            this.RAW.Name = "RAW";
            this.RAW.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RAW.Size = new System.Drawing.Size(101, 20);
            this.RAW.TabIndex = 27;
            this.RAW.Text = "Raw Image";
            this.RAW.UseVisualStyleBackColor = true;
            this.RAW.CheckedChanged += new System.EventHandler(this.RAW_CheckedChanged);
            // 
            // PTOFIRM
            // 
            this.PTOFIRM.AutoSize = true;
            this.PTOFIRM.Cursor = System.Windows.Forms.Cursors.Default;
            this.PTOFIRM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PTOFIRM.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.PTOFIRM.ForeColor = System.Drawing.Color.MintCream;
            this.PTOFIRM.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PTOFIRM.Location = new System.Drawing.Point(2, 4);
            this.PTOFIRM.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PTOFIRM.Name = "PTOFIRM";
            this.PTOFIRM.Size = new System.Drawing.Size(142, 19);
            this.PTOFIRM.TabIndex = 27;
            this.PTOFIRM.Text = "Path To Firmware";
            // 
            // Xm
            // 
            this.Xm.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Xm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Xm.Location = new System.Drawing.Point(6, 85);
            this.Xm.Margin = new System.Windows.Forms.Padding(2);
            this.Xm.Name = "Xm";
            this.Xm.Size = new System.Drawing.Size(270, 22);
            this.Xm.TabIndex = 16;
            // 
            // AutoLdr
            // 
            this.AutoLdr.AutoSize = true;
            this.AutoLdr.Checked = true;
            this.AutoLdr.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AutoLdr.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold);
            this.AutoLdr.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AutoLdr.Location = new System.Drawing.Point(376, 20);
            this.AutoLdr.Margin = new System.Windows.Forms.Padding(2);
            this.AutoLdr.Name = "AutoLdr";
            this.AutoLdr.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.AutoLdr.Size = new System.Drawing.Size(58, 20);
            this.AutoLdr.TabIndex = 27;
            this.AutoLdr.Text = "Auto";
            this.AutoLdr.UseVisualStyleBackColor = true;
            this.AutoLdr.CheckedChanged += new System.EventHandler(this.ISAS2);
            // 
            // Tab
            // 
            this.Tab.Controls.Add(this.MA);
            this.Tab.Controls.Add(this.QCOM1);
            this.Tab.Controls.Add(this.Board);
            this.Tab.Controls.Add(this.QCOM2);
            this.Tab.Controls.Add(this.Diag);
            this.Tab.Controls.Add(this.NC);
            this.Tab.Controls.Add(this.MTK1);
            this.Tab.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            this.Tab.Location = new System.Drawing.Point(77, 0);
            this.Tab.Multiline = true;
            this.Tab.Name = "Tab";
            this.Tab.SelectedIndex = 0;
            this.Tab.Size = new System.Drawing.Size(681, 346);
            this.Tab.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.Tab.TabIndex = 28;
            this.Tab.SelectedIndexChanged += new System.EventHandler(this.Tab_SelectedIndexChanged);
            // 
            // MA
            // 
            this.MA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.MA.Controls.Add(this.groupBox6);
            this.MA.Controls.Add(this.GLOADER);
            this.MA.Location = new System.Drawing.Point(4, 25);
            this.MA.Name = "MA";
            this.MA.Size = new System.Drawing.Size(673, 317);
            this.MA.TabIndex = 5;
            this.MA.Text = "MAIN";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.groupBox6.Controls.Add(this.DBB);
            this.groupBox6.Controls.Add(this.SelLanguage);
            this.groupBox6.Controls.Add(this.LBOX);
            this.groupBox6.ForeColor = System.Drawing.Color.DarkGray;
            this.groupBox6.Location = new System.Drawing.Point(453, 0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(217, 114);
            this.groupBox6.TabIndex = 31;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Language";
            // 
            // DBB
            // 
            this.DBB.AutoSize = true;
            this.DBB.Location = new System.Drawing.Point(6, 89);
            this.DBB.Name = "DBB";
            this.DBB.Size = new System.Drawing.Size(71, 20);
            this.DBB.TabIndex = 31;
            this.DBB.Text = "DEBUG";
            this.DBB.UseVisualStyleBackColor = true;
            this.DBB.CheckedChanged += new System.EventHandler(this.DBB_CheckedChanged);
            // 
            // SelLanguage
            // 
            this.SelLanguage.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.SelLanguage.BackColorAdditional = System.Drawing.Color.Gray;
            this.SelLanguage.BackColorGradientEnabled = false;
            this.SelLanguage.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.SelLanguage.BorderColor = System.Drawing.Color.Tomato;
            this.SelLanguage.BorderColorEnabled = false;
            this.SelLanguage.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.SelLanguage.BorderColorOnHoverEnabled = false;
            this.SelLanguage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SelLanguage.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SelLanguage.ForeColor = System.Drawing.Color.White;
            this.SelLanguage.Location = new System.Drawing.Point(5, 52);
            this.SelLanguage.Margin = new System.Windows.Forms.Padding(2);
            this.SelLanguage.Name = "SelLanguage";
            this.SelLanguage.RippleColor = System.Drawing.Color.Black;
            this.SelLanguage.RoundingEnable = false;
            this.SelLanguage.Size = new System.Drawing.Size(207, 34);
            this.SelLanguage.TabIndex = 32;
            this.SelLanguage.Text = "Apply";
            this.SelLanguage.TextHover = null;
            this.SelLanguage.UseDownPressEffectOnClick = false;
            this.SelLanguage.UseRippleEffect = true;
            this.SelLanguage.UseVisualStyleBackColor = false;
            this.SelLanguage.UseZoomEffectOnHover = false;
            this.SelLanguage.Click += new System.EventHandler(this.SelLanguage_Click);
            // 
            // LBOX
            // 
            this.LBOX.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.LBOX.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.LBOX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LBOX.FormattingEnabled = true;
            this.LBOX.Location = new System.Drawing.Point(5, 24);
            this.LBOX.Margin = new System.Windows.Forms.Padding(2);
            this.LBOX.Name = "LBOX";
            this.LBOX.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LBOX.Size = new System.Drawing.Size(207, 24);
            this.LBOX.TabIndex = 31;
            // 
            // GLOADER
            // 
            this.GLOADER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.GLOADER.Controls.Add(this.SelectLOADER);
            this.GLOADER.Controls.Add(this.label1);
            this.GLOADER.Controls.Add(this.AutoLdr);
            this.GLOADER.Controls.Add(this.LoaderBox);
            this.GLOADER.ForeColor = System.Drawing.Color.DarkGray;
            this.GLOADER.Location = new System.Drawing.Point(8, 0);
            this.GLOADER.Name = "GLOADER";
            this.GLOADER.Size = new System.Drawing.Size(439, 114);
            this.GLOADER.TabIndex = 28;
            this.GLOADER.TabStop = false;
            this.GLOADER.Text = "Select Loader First";
            // 
            // SelectLOADER
            // 
            this.SelectLOADER.AutoSize = true;
            this.SelectLOADER.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.SelectLOADER.BackColorAdditional = System.Drawing.Color.Gray;
            this.SelectLOADER.BackColorGradientEnabled = false;
            this.SelectLOADER.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.SelectLOADER.BorderColor = System.Drawing.Color.Tomato;
            this.SelectLOADER.BorderColorEnabled = false;
            this.SelectLOADER.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.SelectLOADER.BorderColorOnHoverEnabled = false;
            this.SelectLOADER.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SelectLOADER.Enabled = false;
            this.SelectLOADER.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SelectLOADER.ForeColor = System.Drawing.Color.White;
            this.SelectLOADER.Location = new System.Drawing.Point(5, 72);
            this.SelectLOADER.Margin = new System.Windows.Forms.Padding(2);
            this.SelectLOADER.Name = "SelectLOADER";
            this.SelectLOADER.RippleColor = System.Drawing.Color.Black;
            this.SelectLOADER.RoundingEnable = false;
            this.SelectLOADER.Size = new System.Drawing.Size(429, 37);
            this.SelectLOADER.TabIndex = 30;
            this.SelectLOADER.Text = "Select";
            this.SelectLOADER.TextHover = null;
            this.SelectLOADER.UseDownPressEffectOnClick = false;
            this.SelectLOADER.UseRippleEffect = true;
            this.SelectLOADER.UseVisualStyleBackColor = false;
            this.SelectLOADER.UseZoomEffectOnHover = false;
            this.SelectLOADER.Click += new System.EventHandler(this.LOADER_PATH);
            // 
            // QCOM1
            // 
            this.QCOM1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.QCOM1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.QCOM1.Controls.Add(this.TUTR2);
            this.QCOM1.Controls.Add(this.panel1);
            this.QCOM1.Controls.Add(this.GPfir);
            this.QCOM1.Location = new System.Drawing.Point(4, 25);
            this.QCOM1.Name = "QCOM1";
            this.QCOM1.Padding = new System.Windows.Forms.Padding(3);
            this.QCOM1.Size = new System.Drawing.Size(673, 317);
            this.QCOM1.TabIndex = 1;
            this.QCOM1.Text = "QCOM";
            // 
            // TUTR2
            // 
            this.TUTR2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.TUTR2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TUTR2.ForeColor = System.Drawing.Color.MintCream;
            this.TUTR2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.TUTR2.Location = new System.Drawing.Point(5, 160);
            this.TUTR2.Name = "TUTR2";
            this.TUTR2.Size = new System.Drawing.Size(658, 150);
            this.TUTR2.TabIndex = 30;
            this.TUTR2.Text = "1. Checked Raw Image -> Select DIUMP.bin\r\n2. Not Checked Raw Image -> Select Fold" +
    "er with rawprogram0.xml and firmware data\r\n3. For only repartition your phone us" +
    "e patch0.xml as primary rawprograms0!";
            // 
            // GPfir
            // 
            this.GPfir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.GPfir.Controls.Add(this.EraseMeBtn);
            this.GPfir.Controls.Add(this.Flash);
            this.GPfir.Controls.Add(this.DUMPALL);
            this.GPfir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GPfir.ForeColor = System.Drawing.Color.AliceBlue;
            this.GPfir.Location = new System.Drawing.Point(368, -2);
            this.GPfir.Name = "GPfir";
            this.GPfir.Size = new System.Drawing.Size(295, 155);
            this.GPfir.TabIndex = 29;
            this.GPfir.TabStop = false;
            this.GPfir.Text = "Select";
            // 
            // EraseMeBtn
            // 
            this.EraseMeBtn.BackColor = System.Drawing.Color.Tomato;
            this.EraseMeBtn.BackColorAdditional = System.Drawing.Color.Gray;
            this.EraseMeBtn.BackColorGradientEnabled = false;
            this.EraseMeBtn.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.EraseMeBtn.BorderColor = System.Drawing.Color.Tomato;
            this.EraseMeBtn.BorderColorEnabled = false;
            this.EraseMeBtn.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.EraseMeBtn.BorderColorOnHoverEnabled = false;
            this.EraseMeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EraseMeBtn.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EraseMeBtn.ForeColor = System.Drawing.Color.White;
            this.EraseMeBtn.Location = new System.Drawing.Point(7, 113);
            this.EraseMeBtn.Name = "EraseMeBtn";
            this.EraseMeBtn.RippleColor = System.Drawing.Color.Black;
            this.EraseMeBtn.RoundingEnable = false;
            this.EraseMeBtn.Size = new System.Drawing.Size(282, 36);
            this.EraseMeBtn.TabIndex = 34;
            this.EraseMeBtn.Text = "Erase Memory";
            this.EraseMeBtn.TextHover = null;
            this.EraseMeBtn.UseDownPressEffectOnClick = false;
            this.EraseMeBtn.UseRippleEffect = true;
            this.EraseMeBtn.UseVisualStyleBackColor = false;
            this.EraseMeBtn.UseZoomEffectOnHover = false;
            this.EraseMeBtn.Click += new System.EventHandler(this.EraseMeBtn_Click);
            // 
            // Flash
            // 
            this.Flash.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.Flash.BackColorAdditional = System.Drawing.Color.Gray;
            this.Flash.BackColorGradientEnabled = false;
            this.Flash.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.Flash.BorderColor = System.Drawing.Color.Tomato;
            this.Flash.BorderColorEnabled = false;
            this.Flash.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.Flash.BorderColorOnHoverEnabled = false;
            this.Flash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Flash.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Flash.ForeColor = System.Drawing.Color.White;
            this.Flash.Location = new System.Drawing.Point(7, 21);
            this.Flash.Name = "Flash";
            this.Flash.RippleColor = System.Drawing.Color.Black;
            this.Flash.RoundingEnable = false;
            this.Flash.Size = new System.Drawing.Size(282, 40);
            this.Flash.TabIndex = 33;
            this.Flash.Text = "Flash Firmware";
            this.Flash.TextHover = null;
            this.Flash.UseDownPressEffectOnClick = false;
            this.Flash.UseRippleEffect = true;
            this.Flash.UseVisualStyleBackColor = false;
            this.Flash.UseZoomEffectOnHover = false;
            this.Flash.Click += new System.EventHandler(this.Flash_Click);
            // 
            // DUMPALL
            // 
            this.DUMPALL.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.DUMPALL.BackColorAdditional = System.Drawing.Color.Gray;
            this.DUMPALL.BackColorGradientEnabled = false;
            this.DUMPALL.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.DUMPALL.BorderColor = System.Drawing.Color.Tomato;
            this.DUMPALL.BorderColorEnabled = false;
            this.DUMPALL.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.DUMPALL.BorderColorOnHoverEnabled = false;
            this.DUMPALL.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DUMPALL.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DUMPALL.ForeColor = System.Drawing.Color.White;
            this.DUMPALL.Location = new System.Drawing.Point(7, 67);
            this.DUMPALL.Name = "DUMPALL";
            this.DUMPALL.RippleColor = System.Drawing.Color.Black;
            this.DUMPALL.RoundingEnable = false;
            this.DUMPALL.Size = new System.Drawing.Size(282, 40);
            this.DUMPALL.TabIndex = 32;
            this.DUMPALL.Text = "Dump Firmware";
            this.DUMPALL.TextHover = null;
            this.DUMPALL.UseDownPressEffectOnClick = false;
            this.DUMPALL.UseRippleEffect = true;
            this.DUMPALL.UseVisualStyleBackColor = false;
            this.DUMPALL.UseZoomEffectOnHover = false;
            this.DUMPALL.Click += new System.EventHandler(this.DumpALL_CLK);
            // 
            // Board
            // 
            this.Board.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.Board.Controls.Add(this.groupBox1);
            this.Board.Controls.Add(this.ACTBOX);
            this.Board.Controls.Add(this.SLDEV);
            this.Board.Controls.Add(this.DevInfoQCBox);
            this.Board.Location = new System.Drawing.Point(4, 25);
            this.Board.Name = "Board";
            this.Board.Size = new System.Drawing.Size(673, 317);
            this.Board.TabIndex = 3;
            this.Board.Text = "Board_UNL";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.groupBox1.Controls.Add(this.FrBTN);
            this.groupBox1.Controls.Add(this.RDinf);
            this.groupBox1.Controls.Add(this.ReBbtn);
            this.groupBox1.Controls.Add(this.UpgradMDbtn);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.groupBox1.ForeColor = System.Drawing.Color.Cornsilk;
            this.groupBox1.Location = new System.Drawing.Point(322, 151);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(348, 163);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Manufacture";
            // 
            // FrBTN
            // 
            this.FrBTN.BackColor = System.Drawing.Color.CadetBlue;
            this.FrBTN.BackColorAdditional = System.Drawing.Color.Gray;
            this.FrBTN.BackColorGradientEnabled = false;
            this.FrBTN.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.FrBTN.BorderColor = System.Drawing.Color.Tomato;
            this.FrBTN.BorderColorEnabled = false;
            this.FrBTN.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.FrBTN.BorderColorOnHoverEnabled = false;
            this.FrBTN.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FrBTN.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FrBTN.ForeColor = System.Drawing.Color.White;
            this.FrBTN.Location = new System.Drawing.Point(6, 117);
            this.FrBTN.Name = "FrBTN";
            this.FrBTN.RippleColor = System.Drawing.Color.Black;
            this.FrBTN.RoundingEnable = false;
            this.FrBTN.Size = new System.Drawing.Size(336, 37);
            this.FrBTN.TabIndex = 17;
            this.FrBTN.Text = "Factory Reset";
            this.FrBTN.TextHover = null;
            this.FrBTN.UseDownPressEffectOnClick = false;
            this.FrBTN.UseRippleEffect = true;
            this.FrBTN.UseVisualStyleBackColor = false;
            this.FrBTN.UseZoomEffectOnHover = false;
            this.FrBTN.Click += new System.EventHandler(this.FrBTN_Click);
            // 
            // RDinf
            // 
            this.RDinf.BackColor = System.Drawing.Color.CadetBlue;
            this.RDinf.BackColorAdditional = System.Drawing.Color.Gray;
            this.RDinf.BackColorGradientEnabled = false;
            this.RDinf.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.RDinf.BorderColor = System.Drawing.Color.Tomato;
            this.RDinf.BorderColorEnabled = false;
            this.RDinf.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.RDinf.BorderColorOnHoverEnabled = false;
            this.RDinf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RDinf.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RDinf.ForeColor = System.Drawing.Color.White;
            this.RDinf.Location = new System.Drawing.Point(6, 24);
            this.RDinf.Name = "RDinf";
            this.RDinf.RippleColor = System.Drawing.Color.Black;
            this.RDinf.RoundingEnable = false;
            this.RDinf.Size = new System.Drawing.Size(337, 42);
            this.RDinf.TabIndex = 13;
            this.RDinf.Text = "Read Info Manufacture!";
            this.RDinf.TextHover = null;
            this.RDinf.UseDownPressEffectOnClick = false;
            this.RDinf.UseRippleEffect = true;
            this.RDinf.UseVisualStyleBackColor = false;
            this.RDinf.UseZoomEffectOnHover = false;
            this.RDinf.Click += new System.EventHandler(this.ReadINFOdiag_Click);
            // 
            // ReBbtn
            // 
            this.ReBbtn.BackColor = System.Drawing.Color.CadetBlue;
            this.ReBbtn.BackColorAdditional = System.Drawing.Color.Gray;
            this.ReBbtn.BackColorGradientEnabled = false;
            this.ReBbtn.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.ReBbtn.BorderColor = System.Drawing.Color.Tomato;
            this.ReBbtn.BorderColorEnabled = false;
            this.ReBbtn.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.ReBbtn.BorderColorOnHoverEnabled = false;
            this.ReBbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReBbtn.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ReBbtn.ForeColor = System.Drawing.Color.White;
            this.ReBbtn.Location = new System.Drawing.Point(177, 72);
            this.ReBbtn.Name = "ReBbtn";
            this.ReBbtn.RippleColor = System.Drawing.Color.Black;
            this.ReBbtn.RoundingEnable = false;
            this.ReBbtn.Size = new System.Drawing.Size(165, 39);
            this.ReBbtn.TabIndex = 14;
            this.ReBbtn.Text = "Reboot";
            this.ReBbtn.TextHover = null;
            this.ReBbtn.UseDownPressEffectOnClick = false;
            this.ReBbtn.UseRippleEffect = true;
            this.ReBbtn.UseVisualStyleBackColor = false;
            this.ReBbtn.UseZoomEffectOnHover = false;
            this.ReBbtn.Click += new System.EventHandler(this.RB_Click);
            // 
            // UpgradMDbtn
            // 
            this.UpgradMDbtn.BackColor = System.Drawing.Color.CadetBlue;
            this.UpgradMDbtn.BackColorAdditional = System.Drawing.Color.Gray;
            this.UpgradMDbtn.BackColorGradientEnabled = false;
            this.UpgradMDbtn.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.UpgradMDbtn.BorderColor = System.Drawing.Color.Tomato;
            this.UpgradMDbtn.BorderColorEnabled = false;
            this.UpgradMDbtn.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.UpgradMDbtn.BorderColorOnHoverEnabled = false;
            this.UpgradMDbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UpgradMDbtn.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UpgradMDbtn.ForeColor = System.Drawing.Color.White;
            this.UpgradMDbtn.Location = new System.Drawing.Point(6, 72);
            this.UpgradMDbtn.Name = "UpgradMDbtn";
            this.UpgradMDbtn.RippleColor = System.Drawing.Color.Black;
            this.UpgradMDbtn.RoundingEnable = false;
            this.UpgradMDbtn.Size = new System.Drawing.Size(166, 39);
            this.UpgradMDbtn.TabIndex = 15;
            this.UpgradMDbtn.Text = "Upgrade Mode";
            this.UpgradMDbtn.TextHover = null;
            this.UpgradMDbtn.UseDownPressEffectOnClick = false;
            this.UpgradMDbtn.UseRippleEffect = true;
            this.UpgradMDbtn.UseVisualStyleBackColor = false;
            this.UpgradMDbtn.UseZoomEffectOnHover = false;
            this.UpgradMDbtn.Click += new System.EventHandler(this.RecoveryBTN_Click);
            // 
            // ACTBOX
            // 
            this.ACTBOX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.ACTBOX.Controls.Add(this.UnlockFrp);
            this.ACTBOX.Controls.Add(this.EraseDA);
            this.ACTBOX.Controls.Add(this.BoardU);
            this.ACTBOX.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.ACTBOX.ForeColor = System.Drawing.Color.Cornsilk;
            this.ACTBOX.Location = new System.Drawing.Point(322, 3);
            this.ACTBOX.Name = "ACTBOX";
            this.ACTBOX.Size = new System.Drawing.Size(348, 149);
            this.ACTBOX.TabIndex = 20;
            this.ACTBOX.TabStop = false;
            this.ACTBOX.Text = "Action";
            // 
            // UnlockFrp
            // 
            this.UnlockFrp.BackColor = System.Drawing.Color.Tomato;
            this.UnlockFrp.BackColorAdditional = System.Drawing.Color.Gray;
            this.UnlockFrp.BackColorGradientEnabled = false;
            this.UnlockFrp.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.UnlockFrp.BorderColor = System.Drawing.Color.Tomato;
            this.UnlockFrp.BorderColorEnabled = false;
            this.UnlockFrp.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.UnlockFrp.BorderColorOnHoverEnabled = false;
            this.UnlockFrp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UnlockFrp.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UnlockFrp.ForeColor = System.Drawing.Color.White;
            this.UnlockFrp.Location = new System.Drawing.Point(6, 104);
            this.UnlockFrp.Margin = new System.Windows.Forms.Padding(2);
            this.UnlockFrp.Name = "UnlockFrp";
            this.UnlockFrp.RippleColor = System.Drawing.Color.Black;
            this.UnlockFrp.RoundingEnable = false;
            this.UnlockFrp.Size = new System.Drawing.Size(337, 39);
            this.UnlockFrp.TabIndex = 21;
            this.UnlockFrp.Text = "Unlock FRP";
            this.UnlockFrp.TextHover = null;
            this.UnlockFrp.UseDownPressEffectOnClick = false;
            this.UnlockFrp.UseRippleEffect = true;
            this.UnlockFrp.UseVisualStyleBackColor = false;
            this.UnlockFrp.UseZoomEffectOnHover = false;
            this.UnlockFrp.Click += new System.EventHandler(this.UnlockFrp_Click);
            // 
            // EraseDA
            // 
            this.EraseDA.BackColor = System.Drawing.Color.Tomato;
            this.EraseDA.BackColorAdditional = System.Drawing.Color.Gray;
            this.EraseDA.BackColorGradientEnabled = false;
            this.EraseDA.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.EraseDA.BorderColor = System.Drawing.Color.Tomato;
            this.EraseDA.BorderColorEnabled = false;
            this.EraseDA.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.EraseDA.BorderColorOnHoverEnabled = false;
            this.EraseDA.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EraseDA.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EraseDA.ForeColor = System.Drawing.Color.White;
            this.EraseDA.Location = new System.Drawing.Point(6, 61);
            this.EraseDA.Margin = new System.Windows.Forms.Padding(2);
            this.EraseDA.Name = "EraseDA";
            this.EraseDA.RippleColor = System.Drawing.Color.Black;
            this.EraseDA.RoundingEnable = false;
            this.EraseDA.Size = new System.Drawing.Size(337, 39);
            this.EraseDA.TabIndex = 22;
            this.EraseDA.Text = "Erase UserData";
            this.EraseDA.TextHover = null;
            this.EraseDA.UseDownPressEffectOnClick = false;
            this.EraseDA.UseRippleEffect = true;
            this.EraseDA.UseVisualStyleBackColor = false;
            this.EraseDA.UseZoomEffectOnHover = false;
            this.EraseDA.Click += new System.EventHandler(this.EraseDA_Click);
            // 
            // BoardU
            // 
            this.BoardU.BackColor = System.Drawing.Color.Tomato;
            this.BoardU.BackColorAdditional = System.Drawing.Color.Gray;
            this.BoardU.BackColorGradientEnabled = false;
            this.BoardU.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.BoardU.BorderColor = System.Drawing.Color.Tomato;
            this.BoardU.BorderColorEnabled = false;
            this.BoardU.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.BoardU.BorderColorOnHoverEnabled = false;
            this.BoardU.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BoardU.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BoardU.ForeColor = System.Drawing.Color.White;
            this.BoardU.Location = new System.Drawing.Point(6, 20);
            this.BoardU.Margin = new System.Windows.Forms.Padding(2);
            this.BoardU.Name = "BoardU";
            this.BoardU.RippleColor = System.Drawing.Color.Beige;
            this.BoardU.RoundingEnable = false;
            this.BoardU.Size = new System.Drawing.Size(337, 37);
            this.BoardU.TabIndex = 17;
            this.BoardU.Text = "Translation UNL";
            this.BoardU.TextHover = null;
            this.BoardU.UseDownPressEffectOnClick = false;
            this.BoardU.UseRippleEffect = true;
            this.BoardU.UseVisualStyleBackColor = false;
            this.BoardU.UseZoomEffectOnHover = false;
            this.BoardU.Click += new System.EventHandler(this.UNLBTN_Click);
            // 
            // SLDEV
            // 
            this.SLDEV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.SLDEV.Controls.Add(this.DEVICER);
            this.SLDEV.ForeColor = System.Drawing.Color.Cornsilk;
            this.SLDEV.Location = new System.Drawing.Point(10, 3);
            this.SLDEV.Name = "SLDEV";
            this.SLDEV.Size = new System.Drawing.Size(306, 57);
            this.SLDEV.TabIndex = 19;
            this.SLDEV.TabStop = false;
            this.SLDEV.Text = "Select device:";
            // 
            // DEVICER
            // 
            this.DEVICER.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.DEVICER.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DEVICER.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DEVICER.Font = new System.Drawing.Font("Arial", 9.8F, System.Drawing.FontStyle.Bold);
            this.DEVICER.Location = new System.Drawing.Point(5, 20);
            this.DEVICER.Margin = new System.Windows.Forms.Padding(2);
            this.DEVICER.Name = "DEVICER";
            this.DEVICER.Size = new System.Drawing.Size(296, 24);
            this.DEVICER.TabIndex = 16;
            this.DEVICER.SelectedIndexChanged += new System.EventHandler(this.DEVICER_SelectedIndexChanged);
            this.DEVICER.Click += new System.EventHandler(this.DEVICER_SelectedIndexChanged);
            // 
            // DevInfoQCBox
            // 
            this.DevInfoQCBox.Controls.Add(this.MacLBL);
            this.DevInfoQCBox.Controls.Add(this.textBox1);
            this.DevInfoQCBox.Controls.Add(this.AndrVerLBL);
            this.DevInfoQCBox.Controls.Add(this.textBox2);
            this.DevInfoQCBox.Controls.Add(this.HWkey);
            this.DevInfoQCBox.Controls.Add(this.CPUbox);
            this.DevInfoQCBox.Controls.Add(this.label8);
            this.DevInfoQCBox.Controls.Add(this.VERbox);
            this.DevInfoQCBox.Controls.Add(this.label7);
            this.DevInfoQCBox.Controls.Add(this.CHIPbox);
            this.DevInfoQCBox.Controls.Add(this.label6);
            this.DevInfoQCBox.Controls.Add(this.BIDbox);
            this.DevInfoQCBox.Controls.Add(this.label5);
            this.DevInfoQCBox.Controls.Add(this.SNbox);
            this.DevInfoQCBox.Controls.Add(this.label4);
            this.DevInfoQCBox.Controls.Add(this.IMEIbox);
            this.DevInfoQCBox.ForeColor = System.Drawing.Color.Cornsilk;
            this.DevInfoQCBox.Location = new System.Drawing.Point(10, 66);
            this.DevInfoQCBox.Name = "DevInfoQCBox";
            this.DevInfoQCBox.Size = new System.Drawing.Size(306, 248);
            this.DevInfoQCBox.TabIndex = 2;
            this.DevInfoQCBox.TabStop = false;
            this.DevInfoQCBox.Text = "DeviceInfo";
            // 
            // MacLBL
            // 
            this.MacLBL.AutoSize = true;
            this.MacLBL.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MacLBL.Location = new System.Drawing.Point(244, 163);
            this.MacLBL.Name = "MacLBL";
            this.MacLBL.Size = new System.Drawing.Size(36, 16);
            this.MacLBL.TabIndex = 15;
            this.MacLBL.Text = "MAC";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 161);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(232, 22);
            this.textBox1.TabIndex = 14;
            // 
            // AndrVerLBL
            // 
            this.AndrVerLBL.AutoSize = true;
            this.AndrVerLBL.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AndrVerLBL.Location = new System.Drawing.Point(244, 192);
            this.AndrVerLBL.Name = "AndrVerLBL";
            this.AndrVerLBL.Size = new System.Drawing.Size(51, 16);
            this.AndrVerLBL.TabIndex = 13;
            this.AndrVerLBL.Text = "ANVER";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(6, 189);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(232, 22);
            this.textBox2.TabIndex = 12;
            // 
            // HWkey
            // 
            this.HWkey.AutoSize = true;
            this.HWkey.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.HWkey.Location = new System.Drawing.Point(244, 220);
            this.HWkey.Name = "HWkey";
            this.HWkey.Size = new System.Drawing.Size(41, 16);
            this.HWkey.TabIndex = 11;
            this.HWkey.Text = "BKEY";
            // 
            // CPUbox
            // 
            this.CPUbox.BackColor = System.Drawing.SystemColors.Control;
            this.CPUbox.Location = new System.Drawing.Point(6, 217);
            this.CPUbox.Name = "CPUbox";
            this.CPUbox.Size = new System.Drawing.Size(232, 22);
            this.CPUbox.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(244, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "AVER";
            // 
            // VERbox
            // 
            this.VERbox.Location = new System.Drawing.Point(6, 133);
            this.VERbox.Name = "VERbox";
            this.VERbox.ReadOnly = true;
            this.VERbox.Size = new System.Drawing.Size(232, 22);
            this.VERbox.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(244, 108);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "CHIP";
            // 
            // CHIPbox
            // 
            this.CHIPbox.Location = new System.Drawing.Point(6, 105);
            this.CHIPbox.Name = "CHIPbox";
            this.CHIPbox.ReadOnly = true;
            this.CHIPbox.Size = new System.Drawing.Size(232, 22);
            this.CHIPbox.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(244, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "BUID";
            // 
            // BIDbox
            // 
            this.BIDbox.Location = new System.Drawing.Point(6, 77);
            this.BIDbox.Name = "BIDbox";
            this.BIDbox.ReadOnly = true;
            this.BIDbox.Size = new System.Drawing.Size(232, 22);
            this.BIDbox.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(244, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 16);
            this.label5.TabIndex = 3;
            this.label5.Text = "BSN";
            // 
            // SNbox
            // 
            this.SNbox.Location = new System.Drawing.Point(6, 49);
            this.SNbox.Name = "SNbox";
            this.SNbox.ReadOnly = true;
            this.SNbox.Size = new System.Drawing.Size(232, 22);
            this.SNbox.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(244, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "IMEI";
            // 
            // IMEIbox
            // 
            this.IMEIbox.Location = new System.Drawing.Point(6, 21);
            this.IMEIbox.Name = "IMEIbox";
            this.IMEIbox.ReadOnly = true;
            this.IMEIbox.Size = new System.Drawing.Size(232, 22);
            this.IMEIbox.TabIndex = 0;
            // 
            // QCOM2
            // 
            this.QCOM2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.QCOM2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.QCOM2.Controls.Add(this.RdGPT);
            this.QCOM2.Controls.Add(this.WHAT);
            this.QCOM2.Controls.Add(this.PARTLIST);
            this.QCOM2.ForeColor = System.Drawing.Color.Snow;
            this.QCOM2.Location = new System.Drawing.Point(4, 25);
            this.QCOM2.Name = "QCOM2";
            this.QCOM2.Padding = new System.Windows.Forms.Padding(3);
            this.QCOM2.Size = new System.Drawing.Size(673, 317);
            this.QCOM2.TabIndex = 0;
            this.QCOM2.Text = "QCOM_Partitions";
            // 
            // RdGPT
            // 
            this.RdGPT.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.RdGPT.BackColorAdditional = System.Drawing.Color.Gray;
            this.RdGPT.BackColorGradientEnabled = false;
            this.RdGPT.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.RdGPT.BorderColor = System.Drawing.Color.Tomato;
            this.RdGPT.BorderColorEnabled = false;
            this.RdGPT.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.RdGPT.BorderColorOnHoverEnabled = false;
            this.RdGPT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RdGPT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RdGPT.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RdGPT.ForeColor = System.Drawing.Color.White;
            this.RdGPT.Location = new System.Drawing.Point(7, 266);
            this.RdGPT.Name = "RdGPT";
            this.RdGPT.RippleColor = System.Drawing.Color.Black;
            this.RdGPT.RoundingEnable = false;
            this.RdGPT.Size = new System.Drawing.Size(657, 42);
            this.RdGPT.TabIndex = 3;
            this.RdGPT.Text = "Read GPT";
            this.RdGPT.TextHover = null;
            this.RdGPT.UseDownPressEffectOnClick = false;
            this.RdGPT.UseRippleEffect = true;
            this.RdGPT.UseVisualStyleBackColor = false;
            this.RdGPT.UseZoomEffectOnHover = false;
            this.RdGPT.Click += new System.EventHandler(this.RdGPT_Click);
            // 
            // WHAT
            // 
            this.WHAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.WHAT.Controls.Add(this.ReadPA);
            this.WHAT.Controls.Add(this.button7);
            this.WHAT.Controls.Add(this.WritePA);
            this.WHAT.Controls.Add(this.ErasePA);
            this.WHAT.Enabled = false;
            this.WHAT.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
            this.WHAT.ForeColor = System.Drawing.Color.Cornsilk;
            this.WHAT.Location = new System.Drawing.Point(175, 47);
            this.WHAT.Name = "WHAT";
            this.WHAT.Size = new System.Drawing.Size(393, 170);
            this.WHAT.TabIndex = 2;
            this.WHAT.TabStop = false;
            this.WHAT.Text = "NULL";
            this.WHAT.Visible = false;
            // 
            // ReadPA
            // 
            this.ReadPA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(47)))), ((int)(((byte)(60)))));
            this.ReadPA.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.ReadPA.ForeColor = System.Drawing.Color.Yellow;
            this.ReadPA.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ReadPA.Location = new System.Drawing.Point(6, 25);
            this.ReadPA.Name = "ReadPA";
            this.ReadPA.Size = new System.Drawing.Size(377, 42);
            this.ReadPA.TabIndex = 7;
            this.ReadPA.Text = "Read";
            this.ReadPA.UseVisualStyleBackColor = false;
            this.ReadPA.Click += new System.EventHandler(this.READevent_Click_1);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.LightCoral;
            this.button7.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.button7.ForeColor = System.Drawing.Color.Brown;
            this.button7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button7.Location = new System.Drawing.Point(335, 120);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(48, 42);
            this.button7.TabIndex = 5;
            this.button7.Text = "X";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // WritePA
            // 
            this.WritePA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(47)))), ((int)(((byte)(60)))));
            this.WritePA.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.WritePA.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.WritePA.ForeColor = System.Drawing.Color.Yellow;
            this.WritePA.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.WritePA.Location = new System.Drawing.Point(6, 73);
            this.WritePA.Name = "WritePA";
            this.WritePA.Size = new System.Drawing.Size(377, 42);
            this.WritePA.TabIndex = 4;
            this.WritePA.Text = "Write";
            this.WritePA.UseVisualStyleBackColor = false;
            this.WritePA.Click += new System.EventHandler(this.WRITEevent_Click);
            // 
            // ErasePA
            // 
            this.ErasePA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(47)))), ((int)(((byte)(60)))));
            this.ErasePA.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.ErasePA.ForeColor = System.Drawing.Color.Yellow;
            this.ErasePA.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.ErasePA.Location = new System.Drawing.Point(6, 120);
            this.ErasePA.Name = "ErasePA";
            this.ErasePA.Size = new System.Drawing.Size(323, 42);
            this.ErasePA.TabIndex = 3;
            this.ErasePA.Text = "Erase";
            this.ErasePA.UseVisualStyleBackColor = false;
            this.ErasePA.Click += new System.EventHandler(this.ERASEevent_Click);
            // 
            // PARTLIST
            // 
            this.PARTLIST.AllowUserToAddRows = false;
            this.PARTLIST.AllowUserToDeleteRows = false;
            this.PARTLIST.AllowUserToResizeColumns = false;
            this.PARTLIST.AllowUserToResizeRows = false;
            this.PARTLIST.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PARTLIST.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.PARTLIST.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.PARTLIST.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(42)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.Menu;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(42)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PARTLIST.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.PARTLIST.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PARTLIST.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.P,
            this.O,
            this.L});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.Snow;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(47)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PARTLIST.DefaultCellStyle = dataGridViewCellStyle11;
            this.PARTLIST.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.PARTLIST.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.PARTLIST.Location = new System.Drawing.Point(-2, -2);
            this.PARTLIST.Name = "PARTLIST";
            this.PARTLIST.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(47)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.Info;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(47)))), ((int)(((byte)(60)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PARTLIST.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.PARTLIST.RowHeadersVisible = false;
            this.PARTLIST.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.PARTLIST.RowTemplate.ReadOnly = true;
            this.PARTLIST.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.PARTLIST.Size = new System.Drawing.Size(673, 317);
            this.PARTLIST.TabIndex = 0;
            this.PARTLIST.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PARTLIST_CellDoubleClick);
            // 
            // P
            // 
            this.P.HeaderText = "Partition";
            this.P.MinimumWidth = 6;
            this.P.Name = "P";
            this.P.ReadOnly = true;
            // 
            // O
            // 
            this.O.HeaderText = "Offset";
            this.O.MinimumWidth = 6;
            this.O.Name = "O";
            this.O.ReadOnly = true;
            // 
            // L
            // 
            this.L.HeaderText = "Length";
            this.L.MinimumWidth = 6;
            this.L.Name = "L";
            this.L.ReadOnly = true;
            // 
            // Diag
            // 
            this.Diag.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.Diag.Controls.Add(this.groupBox5);
            this.Diag.Controls.Add(this.CMD);
            this.Diag.Location = new System.Drawing.Point(4, 25);
            this.Diag.Name = "Diag";
            this.Diag.Size = new System.Drawing.Size(673, 317);
            this.Diag.TabIndex = 4;
            this.Diag.Text = "Diag_TEST";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.groupBox5.Controls.Add(this.button1);
            this.groupBox5.Controls.Add(this.CLEARDD);
            this.groupBox5.Controls.Add(this.FlashF);
            this.groupBox5.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold);
            this.groupBox5.ForeColor = System.Drawing.Color.Cornsilk;
            this.groupBox5.Location = new System.Drawing.Point(3, 268);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(667, 46);
            this.groupBox5.TabIndex = 23;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Action";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(397, 16);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(232, 25);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // CLEARDD
            // 
            this.CLEARDD.ForeColor = System.Drawing.Color.Red;
            this.CLEARDD.Location = new System.Drawing.Point(633, 16);
            this.CLEARDD.Margin = new System.Windows.Forms.Padding(2);
            this.CLEARDD.Name = "CLEARDD";
            this.CLEARDD.Size = new System.Drawing.Size(29, 25);
            this.CLEARDD.TabIndex = 1;
            this.CLEARDD.Text = "X";
            this.CLEARDD.UseVisualStyleBackColor = true;
            this.CLEARDD.Click += new System.EventHandler(this.CLEARDD_Click);
            // 
            // FlashF
            // 
            this.FlashF.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FlashF.Location = new System.Drawing.Point(5, 16);
            this.FlashF.Margin = new System.Windows.Forms.Padding(2);
            this.FlashF.Name = "FlashF";
            this.FlashF.Size = new System.Drawing.Size(388, 25);
            this.FlashF.TabIndex = 0;
            this.FlashF.Text = "TEST";
            this.FlashF.UseVisualStyleBackColor = true;
            this.FlashF.Click += new System.EventHandler(this.FlashF_Click);
            // 
            // CMD
            // 
            this.CMD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(47)))), ((int)(((byte)(61)))));
            this.CMD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CMD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CMD.ForeColor = System.Drawing.Color.Beige;
            this.CMD.Location = new System.Drawing.Point(2, 2);
            this.CMD.Margin = new System.Windows.Forms.Padding(2);
            this.CMD.Multiline = true;
            this.CMD.Name = "CMD";
            this.CMD.Size = new System.Drawing.Size(669, 272);
            this.CMD.TabIndex = 32;
            // 
            // NC
            // 
            this.NC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.NC.Controls.Add(this.CpuHISIBox);
            this.NC.Controls.Add(this.DSGSDG);
            this.NC.Controls.Add(this.groupBox3);
            this.NC.Controls.Add(this.groupBox2);
            this.NC.Location = new System.Drawing.Point(4, 25);
            this.NC.Margin = new System.Windows.Forms.Padding(2);
            this.NC.Name = "NC";
            this.NC.Size = new System.Drawing.Size(673, 317);
            this.NC.TabIndex = 6;
            this.NC.Text = "HW_COM";
            // 
            // CpuHISIBox
            // 
            this.CpuHISIBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.CpuHISIBox.Controls.Add(this.HISIbootloaders);
            this.CpuHISIBox.ForeColor = System.Drawing.Color.Cornsilk;
            this.CpuHISIBox.Location = new System.Drawing.Point(3, 3);
            this.CpuHISIBox.Name = "CpuHISIBox";
            this.CpuHISIBox.Size = new System.Drawing.Size(306, 57);
            this.CpuHISIBox.TabIndex = 20;
            this.CpuHISIBox.TabStop = false;
            this.CpuHISIBox.Text = "Select Cpu";
            // 
            // HISIbootloaders
            // 
            this.HISIbootloaders.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.HISIbootloaders.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HISIbootloaders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HISIbootloaders.Font = new System.Drawing.Font("Arial", 9.8F, System.Drawing.FontStyle.Bold);
            this.HISIbootloaders.Location = new System.Drawing.Point(5, 20);
            this.HISIbootloaders.Margin = new System.Windows.Forms.Padding(2);
            this.HISIbootloaders.Name = "HISIbootloaders";
            this.HISIbootloaders.Size = new System.Drawing.Size(296, 24);
            this.HISIbootloaders.TabIndex = 16;
            this.HISIbootloaders.SelectedIndexChanged += new System.EventHandler(this.HISIbootloaders_SelectedIndexChanged);
            // 
            // DSGSDG
            // 
            this.DSGSDG.BackColor = System.Drawing.Color.DarkMagenta;
            this.DSGSDG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DSGSDG.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.DSGSDG.ForeColor = System.Drawing.Color.Yellow;
            this.DSGSDG.Location = new System.Drawing.Point(3, 292);
            this.DSGSDG.Multiline = true;
            this.DSGSDG.Name = "DSGSDG";
            this.DSGSDG.ReadOnly = true;
            this.DSGSDG.Size = new System.Drawing.Size(667, 22);
            this.DSGSDG.TabIndex = 15;
            this.DSGSDG.Text = "ALL RIGHTS OF METHOD TO HISI UNLOCKER BELONG TO POTATONV";
            this.DSGSDG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.UNLOCKHISI);
            this.groupBox3.Controls.Add(this.HISI_board_FB);
            this.groupBox3.Controls.Add(this.EnDisFBLOCK);
            this.groupBox3.Controls.Add(this.FBLstHISI);
            this.groupBox3.Controls.Add(this.RdHISIinfo);
            this.groupBox3.Controls.Add(this.isVCOM);
            this.groupBox3.ForeColor = System.Drawing.Color.Cornsilk;
            this.groupBox3.Location = new System.Drawing.Point(315, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(355, 283);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Action";
            // 
            // UNLOCKHISI
            // 
            this.UNLOCKHISI.BackColor = System.Drawing.Color.BlueViolet;
            this.UNLOCKHISI.BackColorAdditional = System.Drawing.Color.Gray;
            this.UNLOCKHISI.BackColorGradientEnabled = false;
            this.UNLOCKHISI.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.UNLOCKHISI.BorderColor = System.Drawing.Color.Tomato;
            this.UNLOCKHISI.BorderColorEnabled = false;
            this.UNLOCKHISI.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.UNLOCKHISI.BorderColorOnHoverEnabled = false;
            this.UNLOCKHISI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UNLOCKHISI.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UNLOCKHISI.ForeColor = System.Drawing.Color.White;
            this.UNLOCKHISI.Location = new System.Drawing.Point(6, 215);
            this.UNLOCKHISI.Name = "UNLOCKHISI";
            this.UNLOCKHISI.RippleColor = System.Drawing.Color.Black;
            this.UNLOCKHISI.RoundingEnable = false;
            this.UNLOCKHISI.Size = new System.Drawing.Size(343, 28);
            this.UNLOCKHISI.TabIndex = 23;
            this.UNLOCKHISI.Text = "Unlock Device";
            this.UNLOCKHISI.TextHover = null;
            this.UNLOCKHISI.UseDownPressEffectOnClick = false;
            this.UNLOCKHISI.UseRippleEffect = true;
            this.UNLOCKHISI.UseVisualStyleBackColor = false;
            this.UNLOCKHISI.UseZoomEffectOnHover = false;
            this.UNLOCKHISI.Click += new System.EventHandler(this.UNLOCKHISI_Click);
            // 
            // HISI_board_FB
            // 
            this.HISI_board_FB.BackColor = System.Drawing.Color.CadetBlue;
            this.HISI_board_FB.BackColorAdditional = System.Drawing.Color.Gray;
            this.HISI_board_FB.BackColorGradientEnabled = false;
            this.HISI_board_FB.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.HISI_board_FB.BorderColor = System.Drawing.Color.Tomato;
            this.HISI_board_FB.BorderColorEnabled = false;
            this.HISI_board_FB.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.HISI_board_FB.BorderColorOnHoverEnabled = false;
            this.HISI_board_FB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.HISI_board_FB.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HISI_board_FB.ForeColor = System.Drawing.Color.White;
            this.HISI_board_FB.Location = new System.Drawing.Point(6, 59);
            this.HISI_board_FB.Name = "HISI_board_FB";
            this.HISI_board_FB.RippleColor = System.Drawing.Color.Black;
            this.HISI_board_FB.RoundingEnable = false;
            this.HISI_board_FB.Size = new System.Drawing.Size(343, 35);
            this.HISI_board_FB.TabIndex = 21;
            this.HISI_board_FB.Text = "Write Key (FASTBOOT)";
            this.HISI_board_FB.TextHover = null;
            this.HISI_board_FB.UseDownPressEffectOnClick = false;
            this.HISI_board_FB.UseRippleEffect = true;
            this.HISI_board_FB.UseVisualStyleBackColor = false;
            this.HISI_board_FB.UseZoomEffectOnHover = false;
            this.HISI_board_FB.Click += new System.EventHandler(this.HISI_board_FB_Click);
            // 
            // EnDisFBLOCK
            // 
            this.EnDisFBLOCK.AutoSize = true;
            this.EnDisFBLOCK.Checked = true;
            this.EnDisFBLOCK.CheckState = System.Windows.Forms.CheckState.Checked;
            this.EnDisFBLOCK.Location = new System.Drawing.Point(6, 189);
            this.EnDisFBLOCK.Name = "EnDisFBLOCK";
            this.EnDisFBLOCK.Size = new System.Drawing.Size(79, 20);
            this.EnDisFBLOCK.TabIndex = 20;
            this.EnDisFBLOCK.Text = "FBLOCK";
            this.EnDisFBLOCK.UseVisualStyleBackColor = true;
            // 
            // FBLstHISI
            // 
            this.FBLstHISI.BackColor = System.Drawing.Color.BlueViolet;
            this.FBLstHISI.BackColorAdditional = System.Drawing.Color.Gray;
            this.FBLstHISI.BackColorGradientEnabled = false;
            this.FBLstHISI.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.FBLstHISI.BorderColor = System.Drawing.Color.Tomato;
            this.FBLstHISI.BorderColorEnabled = false;
            this.FBLstHISI.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.FBLstHISI.BorderColorOnHoverEnabled = false;
            this.FBLstHISI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FBLstHISI.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FBLstHISI.ForeColor = System.Drawing.Color.White;
            this.FBLstHISI.Location = new System.Drawing.Point(6, 249);
            this.FBLstHISI.Name = "FBLstHISI";
            this.FBLstHISI.RippleColor = System.Drawing.Color.Black;
            this.FBLstHISI.RoundingEnable = false;
            this.FBLstHISI.Size = new System.Drawing.Size(343, 28);
            this.FBLstHISI.TabIndex = 19;
            this.FBLstHISI.Text = "Write FBLOCK STATE";
            this.FBLstHISI.TextHover = null;
            this.FBLstHISI.UseDownPressEffectOnClick = false;
            this.FBLstHISI.UseRippleEffect = true;
            this.FBLstHISI.UseVisualStyleBackColor = false;
            this.FBLstHISI.UseZoomEffectOnHover = false;
            this.FBLstHISI.Click += new System.EventHandler(this.FBLstHISI_Click);
            // 
            // RdHISIinfo
            // 
            this.RdHISIinfo.BackColor = System.Drawing.Color.CadetBlue;
            this.RdHISIinfo.BackColorAdditional = System.Drawing.Color.Gray;
            this.RdHISIinfo.BackColorGradientEnabled = false;
            this.RdHISIinfo.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.RdHISIinfo.BorderColor = System.Drawing.Color.Tomato;
            this.RdHISIinfo.BorderColorEnabled = false;
            this.RdHISIinfo.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.RdHISIinfo.BorderColorOnHoverEnabled = false;
            this.RdHISIinfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RdHISIinfo.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RdHISIinfo.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.RdHISIinfo.Location = new System.Drawing.Point(6, 18);
            this.RdHISIinfo.Name = "RdHISIinfo";
            this.RdHISIinfo.RippleColor = System.Drawing.Color.Black;
            this.RdHISIinfo.RoundingEnable = false;
            this.RdHISIinfo.Size = new System.Drawing.Size(343, 35);
            this.RdHISIinfo.TabIndex = 15;
            this.RdHISIinfo.Text = "Read Info (FASTBOOT)";
            this.RdHISIinfo.TextHover = null;
            this.RdHISIinfo.UseDownPressEffectOnClick = false;
            this.RdHISIinfo.UseRippleEffect = true;
            this.RdHISIinfo.UseVisualStyleBackColor = false;
            this.RdHISIinfo.UseZoomEffectOnHover = false;
            this.RdHISIinfo.Click += new System.EventHandler(this.RdHISIinfo_Click);
            // 
            // isVCOM
            // 
            this.isVCOM.AutoSize = true;
            this.isVCOM.Checked = true;
            this.isVCOM.CheckState = System.Windows.Forms.CheckState.Checked;
            this.isVCOM.Location = new System.Drawing.Point(244, 189);
            this.isVCOM.Name = "isVCOM";
            this.isVCOM.Size = new System.Drawing.Size(105, 20);
            this.isVCOM.TabIndex = 14;
            this.isVCOM.Text = "VCOM mode";
            this.isVCOM.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.ASERhisi);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.AVERhi);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.BLkeyHI);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.BUIDhi);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.BSNhi);
            this.groupBox2.ForeColor = System.Drawing.Color.Cornsilk;
            this.groupBox2.Location = new System.Drawing.Point(3, 66);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(306, 220);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Device Info";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(240, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "ASERIAL";
            // 
            // ASERhisi
            // 
            this.ASERhisi.Location = new System.Drawing.Point(5, 82);
            this.ASERhisi.Name = "ASERhisi";
            this.ASERhisi.ReadOnly = true;
            this.ASERhisi.Size = new System.Drawing.Size(232, 22);
            this.ASERhisi.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(240, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 13;
            this.label3.Text = "MODEL";
            // 
            // AVERhi
            // 
            this.AVERhi.Location = new System.Drawing.Point(5, 110);
            this.AVERhi.Name = "AVERhi";
            this.AVERhi.ReadOnly = true;
            this.AVERhi.Size = new System.Drawing.Size(232, 22);
            this.AVERhi.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(4, 173);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 16);
            this.label9.TabIndex = 11;
            this.label9.Text = "Bootloader key";
            // 
            // BLkeyHI
            // 
            this.BLkeyHI.BackColor = System.Drawing.SystemColors.Control;
            this.BLkeyHI.Location = new System.Drawing.Point(5, 192);
            this.BLkeyHI.Name = "BLkeyHI";
            this.BLkeyHI.Size = new System.Drawing.Size(295, 22);
            this.BLkeyHI.TabIndex = 10;
            this.BLkeyHI.Text = "0000000000000000";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(240, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 16);
            this.label12.TabIndex = 5;
            this.label12.Text = "BUILDid";
            // 
            // BUIDhi
            // 
            this.BUIDhi.Location = new System.Drawing.Point(5, 51);
            this.BUIDhi.Name = "BUIDhi";
            this.BUIDhi.ReadOnly = true;
            this.BUIDhi.Size = new System.Drawing.Size(232, 22);
            this.BUIDhi.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(240, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 16);
            this.label13.TabIndex = 3;
            this.label13.Text = "BSN";
            // 
            // BSNhi
            // 
            this.BSNhi.Location = new System.Drawing.Point(5, 23);
            this.BSNhi.Name = "BSNhi";
            this.BSNhi.ReadOnly = true;
            this.BSNhi.Size = new System.Drawing.Size(232, 22);
            this.BSNhi.TabIndex = 2;
            // 
            // MTK1
            // 
            this.MTK1.Location = new System.Drawing.Point(4, 25);
            this.MTK1.Name = "MTK1";
            this.MTK1.Size = new System.Drawing.Size(673, 317);
            this.MTK1.TabIndex = 2;
            this.MTK1.Text = "MTK";
            this.MTK1.UseVisualStyleBackColor = true;
            // 
            // LOGGER
            // 
            this.LOGGER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.LOGGER.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LOGGER.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LOGGER.ForeColor = System.Drawing.Color.Beige;
            this.LOGGER.Location = new System.Drawing.Point(763, 7);
            this.LOGGER.Margin = new System.Windows.Forms.Padding(2);
            this.LOGGER.Multiline = true;
            this.LOGGER.Name = "LOGGER";
            this.LOGGER.ReadOnly = true;
            this.LOGGER.Size = new System.Drawing.Size(476, 339);
            this.LOGGER.TabIndex = 29;
            // 
            // BURG
            // 
            this.BURG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.BURG.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BURG.Controls.Add(this.DiagTag);
            this.BURG.Controls.Add(this.button8);
            this.BURG.Controls.Add(this.button10);
            this.BURG.Controls.Add(this.HISItag);
            this.BURG.Controls.Add(this.button9);
            this.BURG.Controls.Add(this.GPTtag);
            this.BURG.Controls.Add(this.UnlockTag);
            this.BURG.Controls.Add(this.BackupRestoreTag);
            this.BURG.Controls.Add(this.button6);
            this.BURG.Controls.Add(this.button4);
            this.BURG.Controls.Add(this.HomeTag);
            this.BURG.Controls.Add(this.button5);
            this.BURG.Controls.Add(this.BURGBTN);
            this.BURG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(64)))), ((int)(((byte)(83)))));
            this.BURG.Location = new System.Drawing.Point(0, 0);
            this.BURG.Margin = new System.Windows.Forms.Padding(2);
            this.BURG.MaximumSize = new System.Drawing.Size(244, 346);
            this.BURG.MinimumSize = new System.Drawing.Size(72, 346);
            this.BURG.Name = "BURG";
            this.BURG.Size = new System.Drawing.Size(72, 346);
            this.BURG.TabIndex = 30;
            // 
            // DiagTag
            // 
            this.DiagTag.Cursor = System.Windows.Forms.Cursors.Default;
            this.DiagTag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DiagTag.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DiagTag.ForeColor = System.Drawing.Color.MintCream;
            this.DiagTag.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DiagTag.Location = new System.Drawing.Point(70, 306);
            this.DiagTag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DiagTag.Name = "DiagTag";
            this.DiagTag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DiagTag.Size = new System.Drawing.Size(74, 31);
            this.DiagTag.TabIndex = 40;
            this.DiagTag.Text = "Diag Test";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.Location = new System.Drawing.Point(3, 233);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(64, 54);
            this.button8.TabIndex = 33;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button10.BackgroundImage")));
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(2, 291);
            this.button10.Margin = new System.Windows.Forms.Padding(2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(67, 49);
            this.button10.TabIndex = 39;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // HISItag
            // 
            this.HISItag.Cursor = System.Windows.Forms.Cursors.Default;
            this.HISItag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HISItag.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HISItag.ForeColor = System.Drawing.Color.MintCream;
            this.HISItag.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.HISItag.Location = new System.Drawing.Point(195, 72);
            this.HISItag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HISItag.Name = "HISItag";
            this.HISItag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.HISItag.Size = new System.Drawing.Size(39, 16);
            this.HISItag.TabIndex = 38;
            this.HISItag.Text = "HISI";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(124, 54);
            this.button9.Margin = new System.Windows.Forms.Padding(2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(67, 49);
            this.button9.TabIndex = 37;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // GPTtag
            // 
            this.GPTtag.Cursor = System.Windows.Forms.Cursors.Default;
            this.GPTtag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.GPTtag.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.GPTtag.ForeColor = System.Drawing.Color.MintCream;
            this.GPTtag.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.GPTtag.Location = new System.Drawing.Point(70, 241);
            this.GPTtag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.GPTtag.Name = "GPTtag";
            this.GPTtag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.GPTtag.Size = new System.Drawing.Size(89, 37);
            this.GPTtag.TabIndex = 36;
            this.GPTtag.Text = "Partition Manager";
            // 
            // UnlockTag
            // 
            this.UnlockTag.Cursor = System.Windows.Forms.Cursors.Default;
            this.UnlockTag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UnlockTag.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UnlockTag.ForeColor = System.Drawing.Color.MintCream;
            this.UnlockTag.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.UnlockTag.Location = new System.Drawing.Point(70, 183);
            this.UnlockTag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.UnlockTag.Name = "UnlockTag";
            this.UnlockTag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.UnlockTag.Size = new System.Drawing.Size(89, 35);
            this.UnlockTag.TabIndex = 35;
            this.UnlockTag.Text = "Unlock Tool";
            // 
            // BackupRestoreTag
            // 
            this.BackupRestoreTag.AutoEllipsis = true;
            this.BackupRestoreTag.Cursor = System.Windows.Forms.Cursors.Default;
            this.BackupRestoreTag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackupRestoreTag.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BackupRestoreTag.ForeColor = System.Drawing.Color.MintCream;
            this.BackupRestoreTag.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.BackupRestoreTag.Location = new System.Drawing.Point(70, 114);
            this.BackupRestoreTag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.BackupRestoreTag.Name = "BackupRestoreTag";
            this.BackupRestoreTag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.BackupRestoreTag.Size = new System.Drawing.Size(89, 49);
            this.BackupRestoreTag.TabIndex = 34;
            this.BackupRestoreTag.Text = "Backup/restore";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(2, 54);
            this.button6.Margin = new System.Windows.Forms.Padding(2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(67, 49);
            this.button6.TabIndex = 32;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(3, 175);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(64, 49);
            this.button4.TabIndex = 31;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // HomeTag
            // 
            this.HomeTag.Cursor = System.Windows.Forms.Cursors.Default;
            this.HomeTag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HomeTag.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HomeTag.ForeColor = System.Drawing.Color.MintCream;
            this.HomeTag.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.HomeTag.Location = new System.Drawing.Point(70, 77);
            this.HomeTag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.HomeTag.Name = "HomeTag";
            this.HomeTag.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.HomeTag.Size = new System.Drawing.Size(50, 16);
            this.HomeTag.TabIndex = 30;
            this.HomeTag.Text = "Home";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(2, 114);
            this.button5.Margin = new System.Windows.Forms.Padding(2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(67, 49);
            this.button5.TabIndex = 1;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // BURGBTN
            // 
            this.BURGBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(47)))), ((int)(((byte)(60)))));
            this.BURGBTN.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BURGBTN.BackgroundImage")));
            this.BURGBTN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BURGBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BURGBTN.Location = new System.Drawing.Point(-2, 1);
            this.BURGBTN.Margin = new System.Windows.Forms.Padding(2);
            this.BURGBTN.MaximumSize = new System.Drawing.Size(240, 45);
            this.BURGBTN.MinimumSize = new System.Drawing.Size(65, 45);
            this.BURGBTN.Name = "BURGBTN";
            this.BURGBTN.Size = new System.Drawing.Size(69, 45);
            this.BURGBTN.TabIndex = 0;
            this.BURGBTN.UseVisualStyleBackColor = false;
            this.BURGBTN.Click += new System.EventHandler(this.BURGBTN_Click);
            // 
            // PGG
            // 
            this.PGG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.PGG.BackColorProgressLeft = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(204)))), ((int)(((byte)(113)))));
            this.PGG.BackColorProgressRight = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(188)))), ((int)(((byte)(156)))));
            this.PGG.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(140)))), ((int)(((byte)(141)))));
            this.PGG.Location = new System.Drawing.Point(5, 352);
            this.PGG.Margin = new System.Windows.Forms.Padding(2);
            this.PGG.Name = "PGG";
            this.PGG.Size = new System.Drawing.Size(1235, 18);
            this.PGG.Step = 10;
            this.PGG.TabIndex = 31;
            this.PGG.Text = "nProgressBar1";
            this.PGG.Value = 0;
            this.PGG.ValueMaximum = 100;
            this.PGG.ValueMinimum = 0;
            // 
            // Window
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(38)))), ((int)(((byte)(49)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1243, 373);
            this.Controls.Add(this.PGG);
            this.Controls.Add(this.LOGGER);
            this.Controls.Add(this.BURG);
            this.Controls.Add(this.Tab);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Window";
            this.Text = "Huawei_Qualcomm_Diag_Tool";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Tab.ResumeLayout(false);
            this.MA.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.GLOADER.ResumeLayout(false);
            this.GLOADER.PerformLayout();
            this.QCOM1.ResumeLayout(false);
            this.GPfir.ResumeLayout(false);
            this.Board.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ACTBOX.ResumeLayout(false);
            this.SLDEV.ResumeLayout(false);
            this.DevInfoQCBox.ResumeLayout(false);
            this.DevInfoQCBox.PerformLayout();
            this.QCOM2.ResumeLayout(false);
            this.WHAT.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PARTLIST)).EndInit();
            this.Diag.ResumeLayout(false);
            this.Diag.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.NC.ResumeLayout(false);
            this.NC.PerformLayout();
            this.CpuHISIBox.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.BURG.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox pather;
        private System.Windows.Forms.Label DETECTED;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox LoaderBox;
        private System.Windows.Forms.CheckBox AutoXml;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox RAW;
        private System.Windows.Forms.TextBox Xm;
        private System.Windows.Forms.TabControl Tab;
        private System.Windows.Forms.TabPage QCOM2;
        private System.Windows.Forms.TabPage QCOM1;
        private System.Windows.Forms.GroupBox GPfir;
        private System.Windows.Forms.Label TUTR2;
        private System.Windows.Forms.TabPage MTK1;
        private System.Windows.Forms.DataGridView PARTLIST;
        private System.Windows.Forms.DataGridViewTextBoxColumn P;
        private System.Windows.Forms.DataGridViewTextBoxColumn O;
        private System.Windows.Forms.DataGridViewTextBoxColumn L;
        private System.Windows.Forms.CheckBox AutoLdr;
        private System.Windows.Forms.GroupBox WHAT;
        private System.Windows.Forms.Button WritePA;
        private System.Windows.Forms.Button ErasePA;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button ReadPA;
        private System.Windows.Forms.TabPage Board;
        private System.Windows.Forms.TabPage Diag;
        private System.Windows.Forms.ComboBox DEVICER;
        private System.Windows.Forms.GroupBox ACTBOX;
        private System.Windows.Forms.GroupBox SLDEV;
        private System.Windows.Forms.GroupBox DevInfoQCBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox VERbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox CHIPbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox BIDbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox SNbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox IMEIbox;
        private System.Windows.Forms.Label HWkey;
        private System.Windows.Forms.TextBox CPUbox;
        private System.Windows.Forms.TabPage MA;
        private System.Windows.Forms.Label PTOFIRM;
        private System.Windows.Forms.GroupBox GLOADER;
        private System.Windows.Forms.TabPage NC;
        private System.Windows.Forms.Button FlashF;
        private System.Windows.Forms.Panel BURG;
        private System.Windows.Forms.Button BURGBTN;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label HomeTag;
        private UI.NButton Selecty2;
        private UI.NButton Selecty3;
        private System.Windows.Forms.TextBox LOGGER;
        private UI.NButton BoardU;
        private System.Windows.Forms.Button button6;
        private UI.NButton UnlockFrp;
        private UI.NButton EraseDA;
        private UI.NButton Flash;
        private UI.NButton DUMPALL;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label BackupRestoreTag;
        private System.Windows.Forms.Label UnlockTag;
        private System.Windows.Forms.Label GPTtag;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label HISItag;
        private UI.NButton SelectLOADER;
        private UI.NButton RDinf;
        private UI.NButton UpgradMDbtn;
        private UI.NButton ReBbtn;
        private UI.NButton RdGPT;
        private UI.NProgressBar PGG;
        private System.Windows.Forms.Label DiagTag;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox CMD;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label AndrVerLBL;
        private System.Windows.Forms.Button CLEARDD;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox LBOX;
        private System.Windows.Forms.CheckBox DBB;
        private UI.NButton SelLanguage;
        private System.Windows.Forms.GroupBox groupBox1;
        private UI.NButton FrBTN;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label MacLBL;
        private UI.NButton EraseMeBtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox AVERhi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox BLkeyHI;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox BUIDhi;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox BSNhi;
        private System.Windows.Forms.TextBox DSGSDG;
        private System.Windows.Forms.GroupBox groupBox3;
        private UI.NButton RdHISIinfo;
        private System.Windows.Forms.GroupBox CpuHISIBox;
        private System.Windows.Forms.ComboBox HISIbootloaders;
        private System.Windows.Forms.CheckBox isVCOM;
        private UI.NButton FBLstHISI;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ASERhisi;
        private System.Windows.Forms.CheckBox EnDisFBLOCK;
        private UI.NButton HISI_board_FB;
        private UI.NButton UNLOCKHISI;
        private System.Windows.Forms.Button button1;
        private UI.NButton nButton2;
        private System.Windows.Forms.TextBox PatXm;
    }
}