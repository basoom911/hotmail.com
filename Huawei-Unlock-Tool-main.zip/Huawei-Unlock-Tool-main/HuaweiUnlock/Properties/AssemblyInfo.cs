﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HuaweiUnlockTool")]
[assembly: AssemblyDescription("For Unlock huawei bootloader")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("moongamer")]
[assembly: AssemblyProduct("HuaweiUnlockTool")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("6d112ae2-a7f4-4f44-aaf4-4ca50166443d")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
