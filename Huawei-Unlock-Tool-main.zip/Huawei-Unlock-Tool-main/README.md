# Huawei-Unlock-Tool
IT'S FREE!
Unlock bootloader/FRP Huawei | EN/RU
1. BOOTLOADER UNLOCKER
2. FLASH TOOL
3. Partition Flasher
4. Full ROM Flash/Backup!
5. HISI UNLOCKER -> Uses Source Code from <a href="https://github.com/mashed-potatoes/PotatoNV">Potato_NV</a> For mergering programms.
So much editions in code base for allow to work with phone in this tool. ALL in ONE Tool! Multi Language...
For peoples who need like dongle box tool... But without dongle...
<a href="https://ibb.co/jWGcqwN"><img src="https://i.ibb.co/4KyjxRW/Screenshot-2.png" alt="Screenshot-1" border="0"></a>
<a href="https://imgbb.com/"><img src="https://i.ibb.co/TY35QM6/Screenshot-2.png" alt="Screenshot-2" border="0"></a>

# QCOM UNLOCKER
Copyright (C) 2018-2023 Moongamer on 4PDA

# <a href="https://github.com/mashed-potatoes/PotatoNV">Unlocking Huawei devices on Kirin SoCs.</a>
Copyright (C) 2020  Andrey Smirnoff (mashed-potatoes)

Copyright (C) 2019  Penn Mackintosh (penn5)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
<<<<<<< HEAD
along with this program.  If not, see <https://www.gnu.org/licenses/>.
=======
along with this program.  If not, see <https://www.gnu.org/licenses/>.
>>>>>>> e26f91eab40e8565de5b7ae2ecbad743553052b8
